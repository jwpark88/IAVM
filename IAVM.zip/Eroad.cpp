#include <RcppArmadillo.h>
#include <limits>
#include <omp.h>
#define min(x,y) (((x) < (y)) ? (x) : (y))

using namespace Rcpp;
using namespace arma;


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Choose function
double Choose(int x, int y){
	double result1 = 1, result2 = 1, result;
	int iter = y;
	
    if( x< y ){ result = 0;	}else{	
    for(int i = 0; i<iter; i++){
    	result1 = result1*x;
    	result2 = result2*y;
    	y = y-1;
    	x = x-1;   	
	}	
    	
    	
    result = result1/result2;
	}
return(result);
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Count degree of each node 
vec countDegree(vec rowsum){
	int nrow = rowsum.n_elem, ind;
	vec degree = zeros( nrow );
	for(int i = 0; i < nrow; i++ ){
		ind = rowsum(i); 
		if(ind>0){ degree(ind-1) = degree(ind-1) + 1; }
	    }
	return(degree);
}




// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Count edgewise shared partners 
vec countShared(vec rowsum, mat X){
	
	int numedges = sum(rowsum)/2, nrow = rowsum.n_elem ,ind;
	vec hist = zeros(numedges);
	int num = 0;
	for(int k = 0; k< nrow; k++){
        for(int j = 0; j< k+1; j++){
	        if( X(k,j) == 1){  for(int i = 0; i<nrow; i++){ hist(num) =  hist(num) + X(i,k)*X(k,j)*X(j,i); }
            num = num + 1; }
				            
		}
    }
	vec shared = zeros(nrow);
	for(int i = 0; i < numedges; i++ ){
	ind = hist(i);	
	if(ind>0){ shared(ind-1) = shared(ind-1) + 1; }
    }
	return(shared);
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Summary statistics edges gwd gwesp
vec Summary(mat X){
	int nrow = X.n_rows;
    double decay = 0.25;
	vec rowsum = sum(X,1), result = zeros(2);
    
    // Count edgewise shared partners 
    vec shared = countShared(rowsum, X);
    
    
    // Calculate summary statistics
    for(int i = 0; i< nrow; i++){
	result(0) = result(0) + Choose(rowsum(i),1);
	result(1) = result(1) + (   1- pow( (1-exp(-decay)),i+1)  )*shared(i);
    }
    
    result(0)=result(0)/2;
	result(1)=exp(decay)*result(1);   
	
    	 
return(result);
}




// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// random scan gibbs update
vec Gibbs(mat X, vec coef, int cycle){
int nrow = X.n_rows,indi,indj,prei,prej,res;
double decay = 0.25;
vec star = sum(X,1), changestat = zeros(2), Sumstat = Summary(X) ;
rowvec ivec = trans( zeros(nrow) ), jvec = trans( zeros(nrow) );
vec geoweight = zeros(nrow);
for(int i =0; i<nrow; i++){ geoweight(i) = 1- pow( (1-exp(-decay)),i+1); }


    for(int l = 0; l< cycle; l++){
    for(int i = 1; i< nrow; i++){
    for(int j = 0; j< i; j++){
         ivec(i) = 1; jvec(j) = 1;
		 res = 0; 
         	
         // When Xij is 0
         if(X(i,j)==0){  
           indi = star(i) + 1, indj = star(j) + 1; 
           // change statistics of edge
		   changestat(0) = ( Choose(indi,1) + Choose(indj,1) - Choose(star(i),1) - Choose(star(j),1) )/2;

		   // change statistics of gwes
		   changestat(1) = 0;     
           for(int k = 0; k< nrow; k++){
           if(   ( X(i,k) == 1 ) & ( X(j,k) == 1  )   ){
		   prei = sum( X.row(i)%X.row(k) );
   		   prej = sum( X.row(j)%X.row(k) );

   		   changestat(1) = changestat(1) + exp(decay)*geoweight(prei+1-1) ; 
		   if(prei >0){ changestat(1) = changestat(1) - exp(decay)*geoweight(prei-1);} 
 		   changestat(1) = changestat(1) + exp(decay)*geoweight(prej+1-1) ; 
		   if(prej >0){ changestat(1) = changestat(1) - exp(decay)*geoweight(prej-1);} 
           res = res + 1; // X(k,i) multiply X(i,j) +1 multiply X(j,k)
           }
           }
           if(res > 0){ changestat(1) = changestat(1) + exp(decay)*geoweight(res-1); }
     
		   // accept reject step  	       
		   // probability of Xij = 1 for given others are fixed 
           vec r =  exp(trans(coef)*changestat) ;         
           double p = r(0)/(1+r(0));   		   
		   if( randu() < p  ){
		   X(i,j) = X(j,i) = 1; 
		   star(i) = indi; star(j) = indj;		 
		   Sumstat = Sumstat + changestat;
		   }
		   
		   
		 // When Xij is 1  
         }else{
           indi = star(i) - 1, indj = star(j) - 1;	
		   // change statistics of edge
           changestat(0) = ( Choose(star(i),1) + Choose(star(j),1) - Choose(indi,1) - Choose(indj,1) )/2;

           // change statistics of gwesp 
           changestat(1) = 0;
           for(int k = 0; k< nrow; k++){
           if(   ( X(i,k) == 1 ) & ( X(j,k) == 1  )   ){
		   prei = sum( X.row(i)%X.row(k) );
   		   prej = sum( X.row(j)%X.row(k) );
   		   if(prei-1 >0){changestat(1) = changestat(1) - exp(decay)*geoweight(prei-1-1); } 
			changestat(1) = changestat(1) + exp(decay)*geoweight(prei-1); 
 		   if(prej-1 >0){changestat(1) = changestat(1) - exp(decay)*geoweight(prej-1-1); } 
			changestat(1) = changestat(1) + exp(decay)*geoweight(prej-1); 
           res = res + 1; // X(k,i) multiply X(i,j)  multiply X(j,k)
           }
           }
           if(res > 0){ changestat(1) = changestat(1) + exp(decay)*geoweight(res-1); }
		   
		   // accept reject step  	       
		   // probability of Xij = 1 for given others are fixed 
           vec r =  exp(trans(coef)*changestat) ;         
           double p = r(0)/(1+r(0));   		   
		   if( randu() > p  ){
		   X(i,j) = X(j,i) = 0; 
		   star(i) = indi; star(j) = indj;  
		   Sumstat = Sumstat - changestat;
		   }             
         }
        // End of a single update  
        ivec(i) = 0; jvec(j) = 0;
    }
    }   
    }
 
return(Sumstat); 
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Double metropolis hastings algorithm
mat ergmDMH(mat X, mat COV, mat theta, int outer, int cycle){
	
// Initializing part
double logprob,u;                          // used in Outer MCMC
int nCOVcols = COV.n_cols;                 // number of parameters	
vec thetaprev(nCOVcols);                   // before propose in Outer MCMC, previous parameters
vec stat = Summary(X), statprop(nCOVcols); // sufficient statistics
     	
//// Start of OUTER MCMC Chain 
for(int l = 0; l< outer; l++){

//	if( (l > 1000) && (l <= 10000) ){ // adaptively update COV until 10000 iterations 
//	COV = cov(theta);
//    }	

    for(int i = 0; i< nCOVcols; i++){
    	thetaprev[i] = theta(l,i);
    }
    
    vec Znormal = randn(nCOVcols);                                           // multivariate proposal by using Cholesky factorization
    vec thetaprop = trans(  trans(thetaprev) + trans(Znormal)*chol(COV)  );  // proposed parameter

    // proposed auxiliary variable		
	statprop = Gibbs(X, thetaprop, cycle);
	
	// log probability ratio to determine acceptance of Outer MCMC 	   
	vec dummy = ( -0.05*trans(thetaprop)*thetaprop + 0.05*trans(thetaprev)*thetaprev + trans(thetaprev - thetaprop)*(statprop - stat) );
	logprob = dummy[0];
    u = log( randu() );
    if( u< logprob ){
    theta.insert_rows(l+1,trans(thetaprop));
	}else{
	theta.insert_rows(l+1,trans(thetaprev));
	}
		
}
	
return(theta);	
}





// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Simulate pcf on grid and measure distance from data points 
List pAuxgen(mat X, int cycle, int num, int numcore, mat Designmat){

omp_set_num_threads(numcore);
int numpoint = Designmat.n_rows;       // number of designpoints
int ndim = Designmat.n_cols;           // parameter dimension

mat Mu(numpoint, ndim);
mat Cov(numpoint*ndim, ndim);

int i;
#pragma omp parallel shared(Designmat) private(i)
{	
#pragma omp for schedule(static)  
    for(i = 0; i < numpoint; i++){
    	mat pseudo(num,ndim);
        for(int j = 0; j < num; j++){ pseudo.row(j) =  trans( Gibbs(X, trans( Designmat.row( i ) ), cycle) ); }
    	    
    	Mu.row(i) =  mean(pseudo,0) ;    
        Cov.submat( span(ndim*i, ndim*i+ndim-1), span(0, ndim-1) ) = cov(pseudo);
 

    }
}

return List::create(Named("Cov") = Cov, Named("Mu") = Mu);	
}











