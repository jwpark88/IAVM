########## ERGM exmpales  ##########
## change statistics of gwdegree: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2031865/#FD24 ##
## ergm basics: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2743438/

rm(list=ls())
library(coda)
library(Bergm)
library(Rcpp)
library(RcppArmadillo)
library(DiceKriging)
library(DiceDesign)
library(mvtnorm)
library(MASS)
Sys.setenv("PKG_CXXFLAGS"="-fopenmp")
Sys.setenv("PKG_LIBS"="-fopenmp")


########## Call functions ##########
source("http://www.stat.psu.edu/~mharan/batchmeans.R")
sourceCpp("Magnolia.cpp")

########## Run step ##########
data(package='ergm')


###  faus.magnolia network (1461 by 1461)  ###

data(faux.magnolia.high)
faux.magnolia.high
plot(faux.magnolia.high)

### data processing

grade <- faux.magnolia.high %v% "Grade" 
sex <- faux.magnolia.high %v% "Sex" 
sex[sex=="M"] = 1
sex[sex=="F"] = 0
sex <- as.numeric(sex)

# summary statistics for data X
X = as.matrix(faux.magnolia.high)

# Parameter estimation via MLE or MPLE #
formula <- faux.magnolia.high ~ edges + nodematch("Grade",diff=T) + nodematch("Sex",diff=F) +  gwdegree(0.25,fixed=TRUE) + gwesp(0.25,fixed=TRUE)
summary(formula)
Xsummary = Summary(X, grade, sex)
Xsummary

m <-ergm(formula,estimate="MPLE")
m$coef

### 1. Make Design points  via MPLE ###

num.point <- 400
p <- length(Xsummary)
th <- rmvt(num.point, sigma = 3*solve(-m$hessian), df = 8, delta = m$coef )

par(mfrow=c(2,5))
for(i in 1:p){
plot(density(th[,i]))
}



### 2. Simulate pseudodatasets for given design points ###
###  Consturct multivariate Normal Simulator which can replace Gibbs sampler ###


cycle <- 1
numcore <- 20
num <- 50

ptm <- proc.time()
res <- pAuxgen(X, grade,sex, cycle, num, numcore, th)
Auxtime <- proc.time()-ptm
Auxtime

Cov <- res$Cov
Mu <- res$Mu




### 3.  DMH by using multivariate Normal Simulator  (emulate) ###

library(DiceKriging)
library(DiceDesign)

# calculating initial value of normalize const #
ptm <- proc.time()
m1 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,1],num.point,1),covtype = "matern3_2")
m2 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,2],num.point,1),covtype = "matern3_2")
m3 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,3],num.point,1),covtype = "matern3_2")
m4 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,4],num.point,1),covtype = "matern3_2")
m5 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,5],num.point,1),covtype = "matern3_2")
m6 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,6],num.point,1),covtype = "matern3_2")
m7 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,7],num.point,1),covtype = "matern3_2")
m8 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,8],num.point,1),covtype = "matern3_2")
m9 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,9],num.point,1),covtype = "matern3_2")
m10 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,10],num.point,1),covtype = "matern3_2")
GPtime = proc.time()-ptm
GPtime


Niter <- 80000
COV <- solve(-m$hessian)
parameter <- matrix(0,Niter,p)
parameter[1,] <- m$coef

ptm <- proc.time()
for(i in 1:(Niter-1)){
    # print(i)
    # propose 
    prop <- mvrnorm(1, parameter[i,], COV) 
    x.point <- data.frame( (matrix(prop,1)) )

    # Kriging
    mu <- c( predict(m1,x.point, "UK")$mean, predict(m2,x.point, "UK")$mean, predict(m3,x.point, "UK")$mean,
             predict(m4,x.point, "UK")$mean, predict(m5,x.point, "UK")$mean, predict(m6,x.point, "UK")$mean,
             predict(m7,x.point, "UK")$mean, predict(m8,x.point, "UK")$mean, predict(m9,x.point, "UK")$mean, predict(m10,x.point, "UK")$mean)

    # Generate auxiliary variable from simulator 
    id = which.min( apply( abs( t(t(th) - prop) ), 1, sum ) )
    Ysummary <-  mvrnorm(1, mu, Cov[((id-1)*p+1:p),1:p]) 

    # DMH ratio
    logprob = (parameter[i,] - prop)%*%(Ysummary - Xsummary)
    if( log(runif(1)) < logprob ){  parameter[i+1,] <- prop }else{ parameter[i+1,] <- parameter[i,] }
}
MCMCtime = proc.time()-ptm
MCMCtime


save.image("Magnolia.RData")




