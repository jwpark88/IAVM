########## Ising model example ##########
rm(list=ls())
library(fields)
library(lattice)
library(coda)
library(Rcpp)
library(RcppArmadillo)
library(xtable)
library(DiceKriging)
library(DiceDesign)
Sys.setenv("PKG_CXXFLAGS"="-fopenmp")
Sys.setenv("PKG_LIBS"="-fopenmp")

#####   Call C++ functions   #####
sourceCpp("Ising.cpp")   

#####   Call batchmean/ESS/Bhattacharyya distance function   #####
source("http://www.stat.psu.edu/~mharan/batchmeans.R")


##### run step #####

### Simulate the data ### 7
set.seed(7)
N <- 100                    # number of lattice size
X <- ProppWilson(N,N,0.3)   # assume it is true data 
n <- 10000                  # number of MCMC RUN


#### Conduct Moller's Auxiliary method ###
## log likelihood for MPLE ##
pseudoLik <- function(parameter){
             beta <- parameter
             work <- cbind(0, rbind(0, X, 0), 0); c <- 0
             for(i in 2:(N+1)){
                 for(j in 2:(N+1)){
                     p <- exp(2*beta*(work[i,j-1]+work[i,j+1]+work[i-1,j]+work[i+1,j]))
                     p <- p/(1+p)
                     c <- c + dbinom((work[i,j]+1)/2,1,p,log=TRUE)}}
             return(c)
             }

z <- optim(0.1,pseudoLik,control=list(fnscale=-1), method = "BFGS")
MPLE <- z$par; MPLE


#### 0. Conduct Liang's DMH ###

ptm <- proc.time()
Liang <- IsingDMH(n,10,MPLE,0.01,X)
Liangtime = ptme <- proc.time() 
Liangtime


Gold <- IsingDMH(50000,10,MPLE,0.01,X)



### 1. Make Design points  from grid ###

num.point <- 20
th <- seq(0,1,length=num.point+2)[-c(1,num.point+2)]


### 2. Simulate pseudodatasets for given design points ###
###  Consturct multivariate Normal Simulator which can replace Gibbs sampler ###


cycle <- 10
numcore <- 20
num <- 50

ptm <- proc.time()
Simul <- pAuxgen(X, cycle, num, numcore, th)
Auxtime <- proc.time()-ptm
Auxtime

Cov <- apply(Simul,1,var)
Mu <- apply(Simul,1,mean)

#Simul <- matrix(0,num.point,num)
#ptm <- proc.time()
#for(i in 1:num.point){
#   for(j in 1:num){
#        Simul[i,j] <- Energy( Gibb(X,th[i],10) )
#    }
#}
#Auxtime <- proc.time()-ptm
#Auxtime

surrogate <- matrix(0,num.point,num)
for(i in 1:num.point){ surrogate[i,] <- rnorm(num,Mu[i],sqrt(Cov[i])) }



pdf("Ising.pdf",height=3,width=12)
plot(density(Simul[1,]),xlim=c(min(Simul), max(Simul)),main="",xlab=expression(S[1]), lwd=3)
lines(density(surrogate[1,]),col=2,lwd=3,lty=2)
for(i in 2:num.point){
lines(density(Simul[i,]),lwd=3)
lines(density(surrogate[i,]),col=2,lwd=3,lty=2)
}
#legend("topright",c("True","Approx"),col=c(1,2),lwd=rep(3,3),lty=c(1,2),bty="n")
dev.off()





### 3.  DMH by using multivariate Normal Simulator  (emulate) ###

library(DiceKriging)
library(DiceDesign)

# calculating initial value of normalize const #
ptm <- proc.time()
m <- km(~ ., design = data.frame(x=th), response = Mu,covtype = "matern3_2")
GPtime = proc.time()-ptm
GPtime


Xsummary <- Energy(X)
Niter <- 10000
parameter <- rep(0,Niter)
parameter[1] <- MPLE

ptm <- proc.time()
for(i in 1:(Niter-1)){
    # print(i)
    # propose 

    prop <- rnorm(1, parameter[i], 0.01) 
    # Kriging
    mu <- predict(m,newdata=data.frame(x=prop), "UK")$mean

    # Generate auxiliary variable from simulator 
    id = which.min( abs(th - prop) )
    Ysummary <-  rnorm(1, mu, sqrt(Cov[id]))

    # DMH ratio
    logprob = (parameter[i] - prop)%*%(Ysummary - Xsummary)
    if( log(runif(1)) < logprob ){  parameter[i+1] <- prop }else{ parameter[i+1] <- parameter[i] }
}
MCMCtime = proc.time()-ptm
MCMCtime



save.image(file="Ising.RData")




