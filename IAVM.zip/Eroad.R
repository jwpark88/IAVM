########## Facebook-ERGM exmpales  ##########
## change statistics of gwdegree: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2031865/#FD24 ##
## ergm basics: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2743438/

rm(list=ls())
library(coda)
library(Bergm)
library(Rcpp)
library(RcppArmadillo)
library(DiceKriging)
library(DiceDesign)
library(MASS)
library(mvtnorm)
Sys.setenv("PKG_CXXFLAGS"="-fopenmp")
Sys.setenv("PKG_LIBS"="-fopenmp")


########## Call functions ##########
source("http://www.stat.psu.edu/~mharan/batchmeans.R")
sourceCpp("Eroad.cpp")

# copy and paste edges data to txt file
# data = read.table("eroad_combined.txt")
# dim(data)
# library(igraph)
# g.network <- graph.data.frame(data, directed = F)

# make adjacency matrix
# X = as.matrix( as_adj(g.network) )

#save(X, file="eroadnetwork.RData")
load("eroadnetwork.RData")
#dim(X)

# network object 
eroad <- as.network(X,directed=FALSE)
formula <- eroad ~ edges +  gwesp(0.25,fixed=TRUE)
Xsummary = summary(formula)
Xsummary

m <-ergm(formula,estimate="MPLE")
hat <- m$coef
summary(m)
COV <- solve(-m$hessian)
Summary(X)

ptm <- proc.time()
simul <- Gibbs(X,hat,1)
proc.time()-ptm




### 1. Make Design points  via MPLE ###

num.point <- 400
p <- length(Xsummary)
th <- rmvt(num.point, sigma = 5*solve(-m$hessian), df = 8, delta = m$coef )


### 2. Simulate pseudodatasets for given design points ###
###  Consturct multivariate Normal Simulator which can replace Gibbs sampler ###


cycle <- 1
numcore <- 20
num <- 50

ptm <- proc.time()
res <- pAuxgen(X, cycle, num, numcore, th)
Auxtime <- proc.time()-ptm
Auxtime

Cov <- res$Cov
Mu <- res$Mu




### 3.  DMH by using multivariate Normal Simulator  (emulate) ###

library(DiceKriging)
library(DiceDesign)

# calculating initial value of normalize const #
ptm <- proc.time()
m1 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,1],num.point,1),covtype = "matern3_2")
m2 <- km(~ ., design = th[1:num.point,], response = matrix(Mu[1:num.point,2],num.point,1),covtype = "matern3_2")
GPtime = proc.time()-ptm
GPtime


Niter <- 25000
COV <- solve(-m$hessian)
parameter <- matrix(0,Niter,p)
parameter[1,] <- m$coef

ptm <- proc.time()
for(i in 1:(Niter-1)){
   print(i)
  # propose 
  prop <- mvrnorm(1, parameter[i,], COV) 
  x.point <- data.frame( (matrix(prop,1)) )
  
  # Kriging
  mu <- c( predict(m1,x.point, "UK")$mean, predict(m2,x.point, "UK")$mean )
  
  # Generate auxiliary variable from simulator 
  id = which.min( apply( abs( t(t(th) - prop) ), 1, sum ) )
  Ysummary <-  mvrnorm(1, mu, Cov[((id-1)*p+1:p),1:p]) 
  
  # DMH ratio
  logprob = (parameter[i,] - prop)%*%(Ysummary - Xsummary)
  if( log(runif(1)) < logprob ){  parameter[i+1,] <- prop }else{ parameter[i+1,] <- parameter[i,] }
}
MCMCtime = proc.time()-ptm
MCMCtime


save.image("Eroad.RData")


