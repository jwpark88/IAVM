#include <RcppArmadillo.h>
#include <limits>
#include <omp.h>


using namespace Rcpp;
using namespace arma;

// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Summary statistics for Ising model
int Energy(mat X){
    int nrow = X.n_rows, ncol = X.n_cols, s1 = 0, s2 = 0;
	int result;
	
	for(int i = 0; i< nrow-1; i++){
	s1 = s1 + accu( X.row(i)%X.row(i+1) );
    }
	for(int j = 0; j< ncol-1; j++){
	s2 = s2 + accu( X.col(j)%X.col(j+1) );
    }
    
    result = s1 + s2;
    
return(result);
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Perfect sampling
mat ProppWilson(int nrow, int ncol, double b){
	mat Xmin = -1*ones(nrow,ncol), Xmax = ones(nrow,ncol);
	mat work1 = Xmin, work2 = Xmax;
	work1.insert_cols(0,zeros(nrow));
    work1.insert_cols(ncol+1,zeros(nrow));
	work1.insert_rows(0,trans(zeros(ncol+2)));
	work1.insert_rows(nrow+1,trans(zeros(ncol+2)));
	work2.insert_cols(0,zeros(nrow));
    work2.insert_cols(ncol+1,zeros(nrow));
	work2.insert_rows(0,trans(zeros(ncol+2)));
	work2.insert_rows(nrow+1,trans(zeros(ncol+2)));	
    int Time = 1; 
    
    // until Xmin == Xmax  
    while(  accu(abs(Xmax-Xmin)) > 0  ){    	
    Time = 2*Time;
    for(int k = 0; k< Time; k++){
    	// just one component random scan update
        int i = ceil(nrow*randu());   
        int j = ceil(ncol*randu());      
		double u  = randu();		
		// update for Xmin
        double r1 = exp( 2*b*( work1(i,j-1)+work1(i,j+1)+work1(i-1,j)+work1(i+1,j) ) );
        double p1 = r1/(1+r1);                
        if( u < p1  ){
        Xmin( (i-1),(j-1) ) = 1;
        work1(i,j) = 1;
		}else{
		Xmin( (i-1),(j-1) ) = -1;	
		work1(i,j) = -1;
		}
        // update for Xmax
		double r2 = exp( 2*b*( work2(i,j-1)+work2(i,j+1)+work2(i-1,j)+work2(i+1,j) ) );
        double p2 = r2/(1+r2);  
        if( u < p2  ){
        Xmax( (i-1),(j-1) ) = 1;
        work2(i,j) = 1;
		}else{
		Xmax( (i-1),(j-1) ) = -1;	
		work2(i,j) = -1;
		}
  	   } 
	    
    }
	
return(Xmin);
} 


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// random scan gibbs update
mat Gibb(mat initial, double b, double cycle){
	int nrow = initial.n_rows, ncol = initial.n_cols;
	mat work = initial;			
	work.insert_cols(0,zeros(nrow));
    work.insert_cols(ncol+1,zeros(nrow));
	work.insert_rows(0,trans(zeros(ncol+2)));
	work.insert_rows(nrow+1,trans(zeros(ncol+2)));
    int iestop = cycle*nrow*ncol;
    
    for(int k = 0; k< iestop; k++){
    	
        int i = ceil(nrow*randu());   
        int j = ceil(ncol*randu());  
		
        double r = exp( 2*b*( work(i,j-1)+work(i,j+1)+work(i-1,j)+work(i+1,j) ) );
        double p = r/(1+r);                  
        if( randu() < p  ){
        initial( (i-1),(j-1) ) = 1;
        work(i,j) = 1;
		}else{
		initial( (i-1),(j-1) ) = -1;	
		work(i,j) = -1;
		}
	}

return(initial);	
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// MH random scan update 
mat MH(mat initial, double b, double cycle){
	int nrow = initial.n_rows, ncol = initial.n_cols;
	mat work = initial;
	work.insert_cols(0,zeros(nrow));
    work.insert_cols(ncol+1,zeros(nrow));
	work.insert_rows(0,trans(zeros(ncol+2)));
	work.insert_rows(nrow+1,trans(zeros(ncol+2)));
	int iestop = cycle*nrow*ncol;
    
    for(int k = 0; k< iestop; k++){
        int i = ceil(nrow*randu());   
        int j = ceil(ncol*randu());  
        double p = exp( -2*b*work(i,j)*(work(i,j-1)+work(i,j+1)+work(i-1,j)+work(i+1,j)) );
        
        if( randu() < p  ){
        initial( (i-1),(j-1) ) = -initial( (i-1),(j-1) );
        work(i,j) = -work(i,j) ;
		}else{
		initial( (i-1),(j-1) ) = initial( (i-1),(j-1) );	
		work(i,j) = work(i,j);
		}	
    }  

return(initial);	
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Exchange algorithm for Ising model
vec IsingExchange(int outer, double initial,double sigma, mat X){
    vec parameter(outer);
    parameter(0) = initial;
    double logprob,u,bprop;
    double negativeInf = -std::numeric_limits<float>::infinity();;	
    int nrow = X.n_rows, ncol = X.n_cols;
    int XStat = Energy(X), YStat;
    mat Y(nrow,ncol); // auxiliary variable

	// Start of MCMC Chain 
	for(int k = 0; k< outer-1; k++){
        // propose parameters 
        bprop = parameter(k) + sigma*randn();
        // propose auxiliary variables 
		Y = ProppWilson(nrow,ncol,bprop);
        YStat = Energy(Y);
        
        if( bprop > 1 || bprop < 0 ){
		logprob = negativeInf;	
		}else{
        logprob = ( bprop-parameter(k) )*XStat +   ( parameter(k)-bprop )*YStat;
        }
        u = log( randu() );
    	if( u< logprob ){
    	parameter(k+1) = bprop;
		}else{
		parameter(k+1) = parameter(k);
		} 

    }  

return(parameter);
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Double Metropolis Hastings for Ising model
vec IsingDMH(int outer, int inner, double initial, double sigma, mat X){
    vec parameter(outer);
    parameter(0) = initial;
    double logprob,u,bprop;
    double negativeInf = -std::numeric_limits<float>::infinity();;	
    int nrow = X.n_rows, ncol = X.n_cols;
    int XStat = Energy(X), YStat;
    mat Y(nrow,ncol); // auxiliary variable

	// Start of MCMC Chain 
	for(int k = 0; k< outer-1; k++){
        // propose parameters 
        bprop = parameter(k) + sigma*randn();
        // propose auxiliary variables 
		Y = Gibb(X,bprop,inner);
        YStat = Energy(Y);
        
        if( bprop > 1 || bprop < 0 ){
		logprob = negativeInf;	
		}else{
        logprob = ( bprop-parameter(k) )*XStat + ( parameter(k)-bprop )*YStat;
        }
        u = log( randu() );
    	if( u< logprob ){
    	parameter(k+1) = bprop;
		}else{
		parameter(k+1) = parameter(k);
		} 

    }  

return(parameter);
}





// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Simulate pcf on grid and measure distance from data points 
mat pAuxgen(mat X, int cycle, int num, int numcore, vec Designmat){

omp_set_num_threads(numcore);
int numpoint = Designmat.n_rows;       // number of designpoints

mat Simul(numpoint, num);


int i;
#pragma omp parallel shared(Simul, Designmat) private(i)
{	
#pragma omp for schedule(static)  
    for(i = 0; i < numpoint; i++){
        for(int j = 0; j < num; j++){ 
        mat pseudo =  Gibb(X,Designmat(i),cycle);
		Simul(i,j) = Energy( pseudo );
		
		
		 }
    }
}

return(Simul);
}







